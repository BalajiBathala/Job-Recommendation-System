# Standard library imports
import os
import re
from zipfile import ZipFile

# Third-party imports
import pandas as pd
import nltk
from nltk.corpus import stopwords
from sklearn.neighbors import NearestNeighbors
from sklearn.feature_extraction.text import TfidfVectorizer
from ftfy import fix_text
import spacy

# Django imports
from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import HttpResponse
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from .forms import ResumeUploadForm
from .models import UserDetails

# Load English language model for spaCy
spacy.load('en_core_web_sm')
nltk.download('stopwords')


def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        c_password = request.POST['c_password']
        if password == c_password:
            if UserDetails.objects.filter(email=email).exists():
                messages.error(request, 'User with this email already exists')
                return redirect('register')
            new_user = UserDetails(name=name, email=email, password=password)
            new_user.save()
            messages.success(request, 'Successfully Registered!')
            return redirect('login')
            # Redirect to the login page after successful registration
        else:
            messages.error(request, 'Password and Confirm Password do not match!')
            return redirect('register')
    return render(request, 'register.html')


def login(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        try:
            user_obj = UserDetails.objects.get(email=email)
            if user_obj.password == password:
                return redirect('home')
            else:
                messages.error(request, 'Invalid Username or Password!')
        except UserDetails.DoesNotExist:
            messages.error(request, 'Invalid Username or Password!')
    return render(request, 'login.html')


def home(request):
    if request.method == "POST":
        return render(request, 'home.html')
    return render(request, 'home.html')


def upload_resume(request):
    if request.method == 'POST':
        try:
            resume_file = request.FILES['resume']
            file_path = default_storage.save('tmp/' + resume_file.name, ContentFile(resume_file.read()))
            full_file_path = default_storage.path(file_path)
            parser = ResumeParser(full_file_path)
            resume_info = parser.get_extracted_data()
            default_storage.delete(file_path)
            request.session['resume_data'] = resume_info
            context = preprocess_resume_info(resume_info)
            return render(request, 'home2.html', context)
        except Exception as e:
            print(f"Error processing resume: {e}")
            messages.error(request, f'Error processing your resume: {e}')
            return render(request, 'home2.html')
    else:
        form = ResumeUploadForm()
    return render(request, 'home2.html')


def resume_info(request):
    # Implement logic to fetch resume info here
    resume_info = {}  # Placeholder, replace with actual logic
    return render(request, 'home2.html', {'resume_info': resume_info})



def top_jobs(request):
    if request.method == 'POST':
        resume_data = request.session.get('resume_data', {})
        skills = ' '.join(resume_data.get('skills', []))
        user_data_combined = f"{skills}"
        df = pd.read_csv('job_final.csv')
        df['processed_text'] = df['Job_Description'].apply(preprocess_text)
        vectorizer = TfidfVectorizer(min_df=1, analyzer=ngrams, lowercase=False)
        tfidf_matrix = vectorizer.fit_transform(df['processed_text'])
        user_tfidf_vector = vectorizer.transform([user_data_combined])
        nbrs = NearestNeighbors(n_neighbors=10, n_jobs=-1).fit(tfidf_matrix)
        distances, indices = nbrs.kneighbors(user_tfidf_vector)
        top_jobs_indices = indices.flatten()
        top_jobs = df.iloc[top_jobs_indices][['Position', 'Company', 'Location']].reset_index(drop=True)
        top_jobs = df[['Position', 'Company', 'Location']].sample(n=10)
        top_jobs_list = top_jobs.to_dict(orient='records')
        return render(request, 'home3.html', {'top_jobs': top_jobs_list})
    return HttpResponse("Invalid request method")


def preprocess_text(text):
    stopw = set(stopwords.words('english'))
    return ' '.join([word for word in str(text).split() if len(word) > 2 and word not in stopw])


def preprocess_resume_info(resume_info):
    # Preprocess resume information for display
    resume_info = {
        'skills': resume_info.get('skills', []),
        'education': resume_info.get('education', []),
        'experience': resume_info.get('experience', [])
    }
    chunk_size = 5
    skills_chunks = [resume_info['skills'][i:i + chunk_size] for i in range(0, len(resume_info['skills']), chunk_size)]
    return {
        'resume_info': {
            'skills_columns': skills_chunks,
            'education': resume_info['education'],
            'experience': resume_info['experience']
        }
    }


def ngrams(string, n=3):
    string = fix_text(string)
    string = string.encode("ascii", errors="ignore").decode()
    string = string.lower()
    chars_to_remove = [")", "(", ".", "|", "[", "]", "{", "}", "'"]
    rx = '[' + re.escape(''.join(chars_to_remove)) + ']'
    string = re.sub(rx, '', string)
    string = string.replace('&', 'and')
    string = string.replace(',', ' ')
    string = string.replace('-', ' ')
    string = string.title()
    string = re.sub(' +', ' ', string).strip()
    string = ' ' + string + ' '
    string = re.sub(r'[,-./]|\sBD', r'', string)
    ngrams = zip(*[string[i:] for i in range(n)])
    return [''.join(ngram) for ngram in ngrams]
